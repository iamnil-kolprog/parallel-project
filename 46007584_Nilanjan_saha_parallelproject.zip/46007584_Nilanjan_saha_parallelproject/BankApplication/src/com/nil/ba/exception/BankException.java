package com.nil.ba.exception;

public class BankException extends Exception{
	String s;

	public BankException(String s) {
		//super();
		this.s = s;
	}

	@Override
	public String toString() {
		return "BankException [s=" + s + "]";
	}
	
}
