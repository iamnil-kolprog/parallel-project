package com.nil.ba.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.nil.ba.beans.Customer;
import com.nil.ba.service.CBank_Service;

class test {
	
	//Customer c3=new Customer("Nil", (int)(Math.random()*100)+100000, "SAVINGS", "8274985471", "kOL", 3000);
	static HashSet<Customer> hs =new HashSet<>();
	
	CBank_Service c =new CBank_Service();
	
	@Before
	void setUp() throws Exception {
		
		System.out.println("Nil");
	}
	
	@After
	void tearDown() throws Exception {
		
	}
	@Test
	public void add_Acc() {
		Customer c1=new Customer("Abhi", 100060, "SAVINGS", "8274985471", "kOL", 3000);
		Customer c2=new Customer("Nila", 100061, "current", "7003242832", "kOL", 4000);
		Customer c3 =new Customer("gaur", 100062, "Current", "802154789", "hyde", 10000);
		hs.addAll(c.Create_Acc(c1));
		hs.addAll(c.Create_Acc(c2));
		hs.addAll(c.Create_Acc(c3));
		System.out.println(hs);
		//System.out.println(hs);
		}
	
	/*void testIsName() {
		assertEquals(true,c.isName(c2.getCust_Name()));
		
	}*/
	@Test
	public void testDeposit() {
																															/*System.out.println("dfdsfd");
																															int a=c.dep(100060, 500, hs);
																															System.out.println(a);
																															assertEquals(3500,a );*/
		
																																			//HashSet<Customer> dep = c.dep(100060, 500, hs);
		//hs.addAll(dep);
		HashSet<Customer> dep =c.deposit(100050, 1000);
		//System.out.println(hs);
		Iterator<Customer> i =dep.iterator();
		while(i.hasNext()) {
			Customer cus =i.next();
			//System.out.println(cus);
			if(cus.getCust_Acc_No()==100050) {
				assertEquals(6000, cus.getBalance());
			}
		}
	}
	@Test
	public void testWithdraw() {
		/*System.out.println("wwwww");
		int b=c.wit(100061, 200, hs);
		System.out.println(b);
		assertEquals(3800, b);*/
		HashSet<Customer> with =c.withdraw(100053, 2000);
		//hs.addAll(with);
		Iterator<Customer> i =with.iterator();
		while(i.hasNext()) {
			Customer cus =i.next();
			if(cus.getCust_Acc_No()==100053) {
				assertEquals(2000,cus.getBalance());
			}
		}
	}
	@Test
	public void testTransfer() {
		System.out.println("aaaa");
		HashSet<Customer> hf =c.fund_Transfer(100050, 100051, 1000);
		Iterator<Customer> i =hf.iterator();
		while(i.hasNext()) {
			Customer cus=i.next();
			if(cus.getCust_Acc_No()==100050) {
				assertEquals(4000, cus.getBalance());
			}
		}
		//System.out.println(hs);
				
	}

	@Test
	void testIsCellNo() {
		//fail("Not yet implemented");
		assertEquals(true, c.isCellNo("9002435795"));
	}
	@Test
	void show() {
		//%)))
		int bal=c.showBalance(100050);
		assertEquals(5000, bal);		
	}
	@Test
	public void testPrint() {
		System.out.println("ppppp");
		LinkedHashSet<String> lhs =c.print_Trans("");
		int len =lhs.size();
		System.out.println(len);
		assertFalse(len==0);
	}
	
}
