package com.nil.ba.beans;

public class Customer {
	private String cust_Name;
	private int cust_Acc_No;
	private String cust_Type;
	private String cust_cellNo;
	private String branch_Name;
	public int balance;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public Customer(String cust_Name, int cust_Acc_No, String cust_Type, String cust_cellNo, String branch_Name,
			int balance) {
		super();
		this.cust_Name = cust_Name;
		this.cust_Acc_No = cust_Acc_No;
		this.cust_Type = cust_Type;
		this.cust_cellNo = cust_cellNo;
		this.branch_Name = branch_Name;
		this.balance = balance;
	}




	public String getBranch_Name() {
		return branch_Name;
	}
	public void setBranch_Name(String branch_Name) {
		this.branch_Name = branch_Name;
	}
	
	
	public int getCust_Acc_No() {
		return cust_Acc_No;
	}
	public void setCust_Acc_No(int cust_Acc_No) {
		this.cust_Acc_No = cust_Acc_No;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getCust_Name() {
		return cust_Name;
	}
	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}
	public String getCust_Type() {
		return cust_Type;
	}
	public void setCust_Type(String cust_Type) {
		this.cust_Type = cust_Type;
	}
	public String getCust_cellNo() {
		return cust_cellNo;
	}
	public void setCust_cellNo(String cust_cellNo) {
		this.cust_cellNo = cust_cellNo;
	}
	@Override
	public String toString() {
		return "Customer [cust_Name=" + cust_Name + ", cust_Acc_No=" + cust_Acc_No + ", cust_Type=" + cust_Type
				+ ", cust_cellNo=" + cust_cellNo + ", branch_Name=" + branch_Name + ", balance=" + balance + "]";
	}


	
	
	
	
	
	
	
	

}
