/**
 * 
 */
/**
 * @author NILANSAH
 *
 */
package com.nil.ba.ui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;

import com.nil.ba.beans.Customer;
import com.nil.ba.exception.BankException;
import com.nil.ba.service.CBank_Service;

public class BankMain{
	static HashSet< Customer> al_new= new HashSet<>();
	
	public void dum() {
		Iterator< Customer> i=al_new.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}
	static Customer customer =null;
	public static void main(String[] args) throws BankException {
		
		LinkedHashSet<String> tr =new LinkedHashSet<>();
		ArrayList<String> val =new ArrayList<>();
		
		
		
		CBank_Service cb=new CBank_Service();
		
		Scanner sc =new Scanner(System.in);
		int op=0;
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("_______________________________\n");
			System.out.println("*******Bank Application********\n");
			System.out.println("1.Create Account ");
			System.out.println("2.Show Balane");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6. Print Transaction");
			System.out.println("7. ShowAll Customer Details:");
			System.out.println("8. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			try {
			op=sc.nextInt();
			switch(op) {
			
			case 1:
				System.out.println("Enter Customer Name : ");
				customer=new Customer();
				customer.setCust_Name(sc.next());
				System.out.println("Enter Customer cell no : ");
				String cell =sc.next();
				customer.setCust_cellNo(cell);
				//long l=sc.nextLong();
				System.out.println("Enter the account type : ");
				customer.setCust_Type(sc.next());
				
				
				System.out.println("Enter Branch Name : ");
				customer.setBranch_Name(sc.next());
				
				val=cb.validateDetails(customer);
				if(val.size()==0) {
				customer.setCust_Acc_No((int)(Math.random()*100)+100000);
				System.out.println("Account is created");
				System.out.println("Customer Account No is : "+customer.getCust_Acc_No());
				HashSet<Customer> a=cb.Create_Acc(customer);
				al_new.addAll(a);
				}
				else
				{
					for(String vals :val) {
						System.out.println(vals);
					}
				}
				
				
				break;
			case 2:
				System.out.println("Enter your account no. :");
				int takeAccNo=sc.nextInt();
				try {
					if(cb.isAccountSer(takeAccNo)) {
					if(BankMain.isAcc(takeAccNo)) {
						System.out.println("Your balance is : "+cb.showBalance(takeAccNo));
					}
					else
						throw new BankException("Account No. is not matched with exisstence account no.");
					}
					else
						throw new BankException(" You typed aacount no. is invalid format");
				}
				catch(BankException bal) {
					System.out.println(bal);
				}
				break;
			case 3:
				System.out.println("Enter customer Account No :");
				int acc=sc.nextInt();
				System.out.println("Enter amount to Deposit :");
				int amt=sc.nextInt();
				if((cb.isAccountSer(acc))){
					if(BankMain.isAcc(acc)) {
						HashSet<Customer> cd=cb.deposit(acc,amt);
						al_new.addAll(cd);
						tr.addAll(cb.print_Trans(" "));
					}
					else
					{
						throw new BankException("Account No. is not found");
					}
				}
				else
					throw new BankException("You typed aacount no. is invalid format");
				break;
				/*System.out.println("Deposit Successfull");*/ 
				/*HashSet<Customer> cd=cb.deposit(acc,amt);
				al_new.addAll(cd);
				tr.addAll(cb.print_Trans(" "));*/
				
			case 4:
				System.out.println("Enter customer Account No :");
				int acw=sc.nextInt();
				System.out.println("Enter amount to Withdraw :");
				int amtw=sc.nextInt();
				if(BankMain.isAcc(acw)) {
					if(BankMain.isAcc(acw)) {
							HashSet<Customer> cdw=cb.withdraw(acw, amtw);
							al_new.addAll(cdw);
							tr.addAll(cb.print_Trans(" "));
					}
					else
						throw new BankException("Account No. is not found");
					}
				else
					throw new BankException("You typed aacount no. is invalid format") ;
				//System.out.println("Withdrawn Successfull"); 
				break;
				
			case 5:
				System.out.println("Enter Your Account Number : ");
				int acc_n=sc.nextInt();
				System.out.println("Enter Account number to which you want to transfer : ");
				int acc_n2=sc.nextInt();
				System.out.println("Enter amount : ");
				int amt1=sc.nextInt();
				try {
					
					if(BankMain.isAcc(acc_n) && BankMain.isAcc(acc_n2)) {
				
							HashSet<Customer> trns_mon=cb.fund_Transfer(acc_n, acc_n2, amt1);
							al_new.addAll(trns_mon);
							tr.addAll(cb.print_Trans(" "));
					}else
					{
						throw new BankException("Account no.is not matched");
					}
				}catch(BankException b) {
					System.out.println(b);
				}
				break;
			case 6:
				
				tr.addAll(cb.print_Trans(" "));
				for(String si : tr) {
					System.out.println(si);
				}
				break;
			case 7:
				new BankMain().dum();
				break;
			case 8 :
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Option");
			}
		}catch(InputMismatchException i) {
			System.out.println("Error in input");
		}
		}
		
}
	public static boolean isAcc(int acc) {
		customer=new Customer();
		Iterator<Customer> i1=al_new.iterator();
		while(i1.hasNext()) {
			customer=i1.next();
			if(customer.getCust_Acc_No()==acc)
				return true;
		}
		return false;
		
	}
	
}