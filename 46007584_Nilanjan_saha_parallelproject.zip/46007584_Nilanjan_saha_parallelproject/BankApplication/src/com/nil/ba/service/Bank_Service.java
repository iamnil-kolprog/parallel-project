package com.nil.ba.service;

import java.util.HashSet;
import java.util.LinkedHashSet;
import com.nil.ba.beans.Customer;

public interface Bank_Service {
	public HashSet<Customer> Create_Acc(Customer c);
	public int showBalance(int Acc_no);
	public HashSet<Customer> deposit(int Account_No,int amount);
	public HashSet<Customer> withdraw(int Account_No,int amount);
	public LinkedHashSet<String> print_Trans(String s);
	public HashSet<Customer> fund_Transfer(int acc1,int acc2,int amt1);
	
	

}
