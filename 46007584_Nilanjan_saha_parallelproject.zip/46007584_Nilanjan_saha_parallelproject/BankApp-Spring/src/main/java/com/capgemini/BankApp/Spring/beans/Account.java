package com.capgemini.BankApp.Spring.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Account {
	@Id
	@GeneratedValue
	private int accountNumber;
	private long accountOpeningBalance;
	private String accountType;
	
	@OneToOne
	private Customer customer;

	public Account() {
		super();
	}

	public Account(int accountId, long accountOpeningBalance, String accountType, Customer customer) {
		super();
		this.accountNumber = accountId;
		this.accountOpeningBalance = accountOpeningBalance;
		this.accountType = accountType;
		this.customer = customer;
	}

	
	public int getAccountId() {
		return accountNumber;
	}

	public void setAccountId(int accountId) {
		this.accountNumber = accountId;
	}

	public long getAccountOpeningBalance() {
		return accountOpeningBalance;
	}

	public void setAccountOpeningBalance(long accountOpeningBalance) {
		this.accountOpeningBalance = accountOpeningBalance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
