package com.capgemini.BankApp.Spring.exception;

public class IdNotFound extends RuntimeException{
	String message;

	public IdNotFound(String message) {
		super();
		this.message = message;
	}
}
