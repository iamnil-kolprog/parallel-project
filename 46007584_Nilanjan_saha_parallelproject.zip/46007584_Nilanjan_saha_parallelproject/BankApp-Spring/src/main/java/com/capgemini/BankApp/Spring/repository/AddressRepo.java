package com.capgemini.BankApp.Spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BankApp.Spring.beans.Address;

public interface AddressRepo extends JpaRepository<Address, Integer>{

}
