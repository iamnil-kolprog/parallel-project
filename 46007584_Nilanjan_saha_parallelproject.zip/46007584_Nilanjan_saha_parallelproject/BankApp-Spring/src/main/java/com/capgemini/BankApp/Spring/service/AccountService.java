package com.capgemini.BankApp.Spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankApp.Spring.beans.Account;
import com.capgemini.BankApp.Spring.beans.Customer;
import com.capgemini.BankApp.Spring.exception.IdNotFound;
import com.capgemini.BankApp.Spring.repository.AccountRepo;

@Service
public class AccountService {

	@Autowired
	private AccountRepo accountReposit;
	
	@Autowired
	private CustomerService customerService;
	
	
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accountReposit.findAll();
	}


	public Account getAccount(int acc_No) {
		// TODO Auto-generated method stub
		if(!accountReposit.findById(acc_No).isPresent()) {
			throw new IdNotFound("Account NO. "+acc_No+" is not present");
		}
		else {
		List<Account> accounts = getAllAccounts();
		for(Account acc : accounts) {
			if(acc.getAccountId()==acc_No) {
				return acc;
			}
		}
		return null;
		}
	}


	public void addAccount(Account account, int cid) {
		// TODO Auto-generated method stub
		Customer customer = customerService.getCustomer(cid);
		account.setCustomer(customer);
		accountReposit.save(account);
	}


	public void updateAccount(int acc_No, Account account) {
		// TODO Auto-generated method stub
		Account acc = getAccount(acc_No);
		Customer customer = acc.getCustomer();
		account.setAccountId(acc_No);
		account.setCustomer(customer);
		accountReposit.save(account);
	}


	public void deleteAccount(int acc_No) {
		if(!accountReposit.findById(acc_No).isPresent()) {
			throw new IdNotFound("Account NO. "+acc_No+" is not present");
		}
		else {
		accountReposit.deleteById(acc_No);
		}
	}
	

}
