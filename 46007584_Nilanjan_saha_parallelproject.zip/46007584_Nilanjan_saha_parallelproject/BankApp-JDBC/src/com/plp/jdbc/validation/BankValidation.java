package com.plp.jdbc.validation;

import com.plp.jdbc.dao.BankDaoImpl;
import com.plp.jdbc.exception.BankException;

public class BankValidation {

	static BankDaoImpl bankDAOImpl=new BankDaoImpl();
	
	public static boolean nameCheck(String name) throws BankException {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0] > 63 && ch[0] < 90) {
					return true;
				} else {
					throw new BankException("Invalid Name");
				}
			} catch (BankException E) {
				System.out.println(E);
				return false;
			}
		}
		return false;
	}

	public static boolean pinCheck(int pin) throws BankException {
		try {
			String g=Integer.toString(pin);
			if (g.matches("[0-9]+") && g.length() == 4) {
				return true;
			} else {
				throw new BankException("Invalid PIN");

			}
		} catch (BankException e) {
			return false;
		}
	}

	public static boolean phoneNumberCheck(String number) throws BankException {
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new BankException("Invalid Phonenumber");
			}
		} catch (BankException e) {
			return false;
		}
	}
	
	public static boolean accNoCheck(int accountNumber)
	{
		if(bankDAOImpl.checkAccountNumber(accountNumber))
		return true;
		
		System.out.println("INVALID ACCOUNT NUMBER");
		return false;
		
     }
}